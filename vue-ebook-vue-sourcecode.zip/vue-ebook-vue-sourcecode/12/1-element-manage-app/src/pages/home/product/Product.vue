<template>
  <router-view></router-view>
</template>

<script>
// 下面是 Vue 组件
export default {
  data() {
    return {};
  }
};
</script>

<style>
</style>
