<template>
  <div>{{ message }}</div>
</template>
    
<script>
export default({
  data() {
    return {
      message: "欢迎来到Vue的世界"
    };
  }
});
</script>
