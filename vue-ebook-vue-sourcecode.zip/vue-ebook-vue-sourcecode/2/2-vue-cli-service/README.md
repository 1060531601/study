## 说明
``` cmd
# 全局安装
npm install -g @vue/cli @vue/cli-service-global

# 开发环境
vue serve App.vue

# 生产环境
vue build App.vue
```