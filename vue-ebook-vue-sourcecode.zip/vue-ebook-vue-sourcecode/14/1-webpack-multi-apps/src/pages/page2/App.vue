<template>
	<div id="my_app" class="wrapper">
		<div class="zhubo-main">
			<div class="zhubo-tab">
				<ul class="tab-nav">
					Hello Page2
				</ul>
			</div>
			<div class="zhubo-tab-cont">
			</div>
		</div>
	</div>
</template>  

<script>
export default {
	name: 'App',
	components: {},
}
</script>
<style>
</style>
