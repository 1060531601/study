# 文章地址
[《9102全员学Vue--2.怎么三两下拼出一个页面》](https://godbasin.github.io/2019/07/11/vue-for-everyone-2/)

## Project setup
```
# 安装依赖
npm run install

# 本地启动项目
npm run serve

# 打包构建
npm run build

# lint 检查和处理
npm run lint
```
