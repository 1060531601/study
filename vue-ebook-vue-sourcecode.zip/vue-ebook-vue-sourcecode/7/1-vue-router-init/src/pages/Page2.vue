<template>
  <div>Page2</div>
</template>

<script>
// 下面是 Vue 组件
export default {
  data() {
    return {};
  },
  methods: {}
};
</script>

<style>
</style>
