<template>
  <div>Page1</div>
</template>

<script>
// 下面是 Vue 组件
export default {
  data() {
    return {};
  },
  methods: {}
};
</script>

<style>
</style>
