---
home: true
actionText: 快速阅读 →
actionLink: /basic/1/basic-1-1.md
features:
  - title: 基础类文档
    details: 基础类文档描述。
  - title: Vue类文档
    details: Vue类文档描述。
  - title: 其他补充
    details: 其他补充描述。
footer: MIT Licensed | Copyright © 2018-present 被删
---

# Element弹窗
<MyDialog/>